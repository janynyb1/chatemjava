import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 1234); // Conecta-se ao servidor local na porta 1234

        // Prepara os fluxos de entrada e saída
        Scanner in = new Scanner(socket.getInputStream());
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        // Loop principal do cliente
        while (true) {
            System.out.print("Digite uma mensagem: ");
            String message = new Scanner(System.in).nextLine(); // Lê a mensagem digitada pelo usuário
            out.println(message); // Envia a mensagem para o servidor

            String response = in.nextLine(); // Aguarda a resposta do servidor
            System.out.println("Servidor diz: " + response);
        }
    }
}