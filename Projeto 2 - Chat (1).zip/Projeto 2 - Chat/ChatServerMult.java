import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ChatServerMult {
    private static List<Socket> clients = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(1234); // Porta do servidor

        System.out.println("Servidor iniciado. Aguardando conexões...");

        while (true) {
            Socket clientSocket = server.accept(); // Aceita uma conexão de cliente
            System.out.println("Cliente conectado: " + clientSocket);
            clients.add(clientSocket);

            // Cria uma nova thread para tratar a conexão do cliente
            Thread clientThread = new Thread(() -> {
                try {
                    handleClient(clientSocket);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            clientThread.start();
        }
    }

    private static void handleClient(Socket clientSocket) throws IOException {
        // Prepara os fluxos de entrada e saída
        Scanner in = new Scanner(clientSocket.getInputStream());
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

        // Loop principal do cliente
        while (true) {
            String message = in.nextLine(); // Aguarda a mensagem do cliente
            System.out.println("Cliente diz: " + message);

            // Envia a mensagem para todos os clientes conectados (incluindo o remetente)
            for (Socket client : clients) {
                PrintWriter clientOut = new PrintWriter(client.getOutputStream(), true);
                clientOut.println("Cliente diz: " + message);
            }
        }
    }
}
