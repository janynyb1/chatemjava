import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ChatServer {
    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(1234); // Porta do servidor
        
        System.out.println("Servidor iniciado. Aguardando conexões...");

        Socket clientSocket = server.accept(); // Aceita uma conexão de cliente
        System.out.println("Cliente conectado: " + clientSocket);

        // Prepara os fluxos de entrada e saída
        Scanner in = new Scanner(clientSocket.getInputStream());
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

        // Loop principal do servidor
        while (true) {
            String message = in.nextLine(); // Aguarda a mensagem do cliente
            System.out.println("Cliente diz: " + message);
            out.println("Recebido: " + message); // Envia uma resposta ao cliente
        }
    }
}
